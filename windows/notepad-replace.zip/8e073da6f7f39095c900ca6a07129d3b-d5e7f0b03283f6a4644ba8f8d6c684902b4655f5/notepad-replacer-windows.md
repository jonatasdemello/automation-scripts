## Replacing Notepad with Notepad++ in Windows 10

1. Start an __elevated or administrator Command Prompt__.

2. Copy the following command and paste it in the Command Prompt window:
```
reg add "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\notepad.exe" /v "Debugger" /t REG_SZ /d "\"%ProgramFiles%\Notepad++\notepad++.exe\" -notepadStyleCmdline -z" /f
```
To undo (reverse) the replacement, use the following command:
```
reg delete "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\notepad.exe" /v "Debugger" /f
```

3. Close Command Prompt.

### Download [REG File Here](https://gist.github.com/P1N2O/bffa44f79724d74c96b9ffd3db0fc1af/raw/5c47206911aacdb8056617cd6fd34c420840b103/notepad-replacer-windows.reg) (Right-Click > Save link as...).